const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "requests.json");
const FRONTEND_DIR = path.join(__dirname, "..", "frontend");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

app.use(express.json({ limit: "100kb" }));
app.use(express.static(FRONTEND_DIR));

function readRequests() {
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}
function writeRequests(items) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2));
}

function clean(value, max = 500) {
  return String(value ?? "").trim().slice(0, max);
}

app.get("/api/requests", (req, res) => {
  // Prototype endpoint. Production version must require authenticated staff.
  const requests = readRequests().sort(
    (a, b) => new Date(a.requestedTime) - new Date(b.requestedTime)
  );
  res.json(requests);
});

app.post("/api/requests", (req, res) => {
  const body = req.body || {};
  const required = ["studentName", "studentId", "phone", "pickupLocation", "destination", "requestedTime"];

  for (const field of required) {
    if (!clean(body[field])) {
      return res.status(400).json({ error: `${field} is required.` });
    }
  }

  const requestedTime = new Date(body.requestedTime);
  if (Number.isNaN(requestedTime.getTime())) {
    return res.status(400).json({ error: "Invalid requested time." });
  }

  const request = {
    id: crypto.randomUUID(),
    studentName: clean(body.studentName, 120),
    studentId: clean(body.studentId, 80),
    phone: clean(body.phone, 40),
    pickupLocation: clean(body.pickupLocation, 300),
    destination: clean(body.destination, 300),
    requestedTime: requestedTime.toISOString(),
    notes: clean(body.notes, 1000),
    status: "Pending",
    createdAt: new Date().toISOString()
  };

  const requests = readRequests();
  requests.push(request);
  writeRequests(requests);

  res.status(201).json(request);
});

app.patch("/api/requests/:id", (req, res) => {
  const allowed = ["Pending", "Assigned", "In Progress", "Completed", "Cancelled"];
  const status = clean(req.body?.status, 30);

  if (!allowed.includes(status)) {
    return res.status(400).json({ error: "Invalid status." });
  }

  const requests = readRequests();
  const item = requests.find(r => r.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Request not found." });

  item.status = status;
  item.updatedAt = new Date().toISOString();
  writeRequests(requests);
  res.json(item);
});

app.get("*", (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Campus Safety Escort running at http://localhost:${PORT}`);
});
