# Campus Safety Escort Request System

A simple full-stack starter project for a campus women's/student safety escort request workflow.

## Features
- Student submits pickup/current location, destination, requested date/time, name, student ID, phone, and notes.
- Server validates the request and stores it in a local JSON file.
- Admin-style requests page shows submitted requests and lets staff update status.
- Responsive web UI.
- No external map or location-tracking service is required.

## Important
This is a prototype, not a production safety system. For real deployment, add authentication, HTTPS, encrypted storage, access control, audit logs, rate limiting, secure session handling, database backups, privacy/retention policies, and a real emergency escalation process.

## Run

Requires Node.js 18+.

```bash
cd backend
npm install
npm start
```

Then open:
http://localhost:3000

The server uses `backend/data/requests.json` for prototype storage.
