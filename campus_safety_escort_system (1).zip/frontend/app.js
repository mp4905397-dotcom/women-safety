const form = document.getElementById("escortForm");
const formMessage = document.getElementById("formMessage");
const studentView = document.getElementById("studentView");
const staffView = document.getElementById("staffView");
const requestsEl = document.getElementById("requests");

document.getElementById("staffBtn").addEventListener("click", () => {
  studentView.classList.add("hidden");
  staffView.classList.remove("hidden");
  loadRequests();
});
document.getElementById("backBtn").addEventListener("click", () => {
  staffView.classList.add("hidden");
  studentView.classList.remove("hidden");
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  formMessage.textContent = "Submitting…";

  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const response = await fetch("/api/requests", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(data)
    });
    const result = await response.json();

    if (!response.ok) throw new Error(result.error || "Could not submit request.");

    form.reset();
    formMessage.textContent =
      `Request submitted. Reference: ${result.id.slice(0, 8).toUpperCase()}`;
  } catch (err) {
    formMessage.textContent = err.message;
  }
});

async function loadRequests() {
  requestsEl.innerHTML = "<p>Loading…</p>";
  try {
    const response = await fetch("/api/requests");
    const requests = await response.json();

    if (!requests.length) {
      requestsEl.innerHTML = "<p>No escort requests yet.</p>";
      return;
    }

    requestsEl.innerHTML = requests.map(renderRequest).join("");

    requestsEl.querySelectorAll("select[data-id]").forEach(select => {
      select.addEventListener("change", async () => {
        await fetch(`/api/requests/${select.dataset.id}`, {
          method: "PATCH",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({status: select.value})
        });
        loadRequests();
      });
    });
  } catch {
    requestsEl.innerHTML = "<p>Could not load requests.</p>";
  }
}

function renderRequest(r) {
  const when = new Date(r.requestedTime).toLocaleString();
  return `
    <article class="request">
      <h3>${escapeHtml(r.studentName)} — ${escapeHtml(r.studentId)}</h3>
      <div class="meta">Phone: ${escapeHtml(r.phone)}</div>
      <p><strong>Pickup:</strong> ${escapeHtml(r.pickupLocation)}</p>
      <p><strong>Destination:</strong> ${escapeHtml(r.destination)}</p>
      <p><strong>Requested:</strong> ${escapeHtml(when)}</p>
      ${r.notes ? `<p><strong>Notes:</strong> ${escapeHtml(r.notes)}</p>` : ""}
      <div class="statusRow">
        <strong>Status</strong>
        <select data-id="${r.id}">
          ${["Pending","Assigned","In Progress","Completed","Cancelled"]
            .map(s => `<option ${s === r.status ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </div>
    </article>`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;").replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
